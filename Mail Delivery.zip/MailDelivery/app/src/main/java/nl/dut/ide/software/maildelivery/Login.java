package nl.dut.ide.software.maildelivery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity {

    EditText etEmail, etPassword;
    Button btnLogin;
    FirebaseAuth mFirebaseAuth;

    private FirebaseAuth.AuthStateListener mAuthStateListener;

    //TextView tvForgetPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //by clicking the register text view, go to the register page
        TextView tvRegister = (TextView) findViewById(R.id.tvRegisterId);
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRegister();
            }
        });

        //setting up the firebase, email, password, loginButton
        etEmail = findViewById(R.id.etInputEmailIdLogin);
        etPassword = findViewById(R.id.etInputPasswordIdLogin);
        btnLogin = findViewById(R.id.btnLoginId);
        mFirebaseAuth = FirebaseAuth.getInstance();


        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = mFirebaseAuth.getCurrentUser();
                if (mFirebaseUser != null){
                    //Toast toast = Toast.makeText(Login.this, "You are logged in", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.BOTTOM, 0, 100);
                    //toast.show();
                    Intent intent = new Intent(Login.this, HomeScreen.class);
                    startActivity(intent);
                }
                /*else {
                    Toast toast = Toast.makeText(Login.this, "Please login", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.BOTTOM, 0, 100);
                    toast.show();
                }*/
            }
        };

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();

                //check if the user filled in everything (backwards because email error should occur first)
                if (password.isEmpty()) {
                    etPassword.setError("Please enter password");
                    etPassword.requestFocus();
                }
                if (email.isEmpty()){
                    etEmail.setError("Please enter email");
                    etEmail.requestFocus();
                }

                //if all things are filled in
                if (!email.isEmpty() && !password.isEmpty()){
                    mFirebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()){
                                Toast toast = Toast.makeText(Login.this, "Login error, please try again", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.BOTTOM, 0, 100);
                                toast.show();
                            }
                            else {
                                Intent intToHomeScreen = new Intent(Login.this, HomeScreen.class);
                                startActivity(intToHomeScreen);
                            }
                        }
                    });
                }
            }
        });
    }


    @Override
    protected void onStart() {
        super.onStart();
        mFirebaseAuth.addAuthStateListener(mAuthStateListener);
    }

    public void openRegister(){
        Intent intent = new Intent(this, Register.class);
        startActivity(intent);
    }
}
