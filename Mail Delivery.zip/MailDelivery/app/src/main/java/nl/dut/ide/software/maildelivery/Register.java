package nl.dut.ide.software.maildelivery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {

    FirebaseAuth mFirebaseAuth;
    EditText etEmail, etPassword, etPasswordCheck;
    Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //go from this page back to the the login page by clicking the 'back arrow' at the top left
        ImageView tvBackToLastPage = (ImageView) findViewById(R.id.ivBackToLastPageId);
        tvBackToLastPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToLastPage();
            }
        });

        //setting up the firebase, email, password, passwordCheck, registerButton
        mFirebaseAuth = FirebaseAuth.getInstance();
        etEmail = findViewById(R.id.etInputEmailId);
        etPassword = findViewById(R.id.etInputPasswordId);
        etPasswordCheck = findViewById(R.id.etInputPasswordCheckId);
        btnRegister = findViewById(R.id.btnRegisterId);

        //react to what the user filled in or did not fill in
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                String passwordCheck = etPasswordCheck.getText().toString();

                //check if the user filled in everything (backwards because email error should occur first)
                if (passwordCheck.isEmpty()){
                    etPasswordCheck.setError("Please re-enter password");
                    etPasswordCheck.requestFocus();
                }
                if (password.isEmpty()) {
                    etPassword.setError("Please enter password");
                    etPassword.requestFocus();
                }
                if (email.isEmpty()){
                   etEmail.setError("Please enter email");
                   etEmail.requestFocus();
                }

                //if all things are filled in
                if (!email.isEmpty() && !password.isEmpty() && !passwordCheck.isEmpty()){

                    // //check if both passwords are the same, register if everything is correct,
                    if (!password.equals(passwordCheck)){
                        etPasswordCheck.setError("Passwords are not the same");
                        etPasswordCheck.requestFocus();
                    }
                    else {
                        mFirebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (!task.isSuccessful()){
                                    Toast toast = Toast.makeText(Register.this, "Registration unsuccessful, please try again", Toast.LENGTH_SHORT);
                                    toast.setGravity(Gravity.BOTTOM, 0, 100);
                                    toast.show();
                                }
                                else {
                                    startActivity(new Intent(Register.this, EditPersonInfo.class));
                                }
                            }
                        });
                    }
                }
            }
        });
    }

    private void backToLastPage(){
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
    }
}
