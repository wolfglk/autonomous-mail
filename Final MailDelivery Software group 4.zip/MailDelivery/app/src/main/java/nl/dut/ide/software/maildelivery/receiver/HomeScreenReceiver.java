package nl.dut.ide.software.maildelivery.receiver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Trace;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;

import nl.dut.ide.software.maildelivery.R;
import nl.dut.ide.software.maildelivery.login.Login;
import nl.dut.ide.software.maildelivery.sender.NfcScanSender;

public class HomeScreenReceiver extends AppCompatActivity {

    Button btnLogout;
    Button btnTrackTrace;

    String currentUid;
    String uidLocation;

    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mFirebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen_receiver);

        getSupportActionBar().setTitle("BMW Mail Delivery: Home screen");

        btnLogout = (Button) findViewById(R.id.btnReceiverLogOutId);
        btnTrackTrace = (Button) findViewById(R.id.btnHomeScreenTrackTraceId);

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intToLogin = new Intent(HomeScreenReceiver.this, Login.class);
                startActivity(intToLogin);
            }
        });

        btnTrackTrace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intToLogin = new Intent(HomeScreenReceiver.this, PlanningReceiver.class);
                startActivity(intToLogin);
            }
        });




        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mFirebaseAuth = FirebaseAuth.getInstance();

        currentUid = mFirebaseAuth.getUid();
        DatabaseReference mDatabaseReff = mFirebaseDatabase.getReference().child("Member").child(currentUid);
        mDatabaseReff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                uidLocation = dataSnapshot.child("userLocation").getValue().toString().toLowerCase();

                GetData(uidLocation);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });




    }


    //
    private void GetData(String uidLocationTwo) {
        DatabaseReference mDatabaseRef = mFirebaseDatabase.getReference().child("Vehicles").child("Vehicle 2");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String currentLocation = dataSnapshot.child("currentLocation").getValue().toString();

                String dropOffLocationsStringList = dataSnapshot.child("dropOffLocations").getValue().toString();
                String dropOffLocationsString = dropOffLocationsStringList.substring(1, dropOffLocationsStringList.length()-1);
                ArrayList<String> dropOffLocations = new ArrayList<String>(Arrays.asList(dropOffLocationsString.split(", ")));

                SendMessage(currentLocation, dropOffLocations, uidLocationTwo);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void SendMessage(String currentLocation, ArrayList<String> dropOffLocations, String uidLocationThree){
        for (int count = 0; count < dropOffLocations.size(); count++){
            String dropOffLocation = dropOffLocations.get(count);

            if (dropOffLocation.equals(currentLocation)){

                if (uidLocationThree.equals(currentLocation)) {
                    startActivity(new Intent(HomeScreenReceiver.this, NfcScanReceiver.class));
                }
                else {
                    break;
                }
            }
        }
    }








}
