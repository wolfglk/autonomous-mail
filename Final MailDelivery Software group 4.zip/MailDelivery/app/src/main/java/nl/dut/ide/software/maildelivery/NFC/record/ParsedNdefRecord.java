package nl.dut.ide.software.maildelivery.NFC.record;

public interface ParsedNdefRecord {

    String str();

}