package nl.dut.ide.software.maildelivery.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Color;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;
import java.util.Objects;

import nl.dut.ide.software.maildelivery.NFC.parser.NdefMessageParser;
import nl.dut.ide.software.maildelivery.NFC.record.ParsedNdefRecord;
import nl.dut.ide.software.maildelivery.receiver.HomeScreenReceiver;
import nl.dut.ide.software.maildelivery.sender.HomeScreenSender;
import nl.dut.ide.software.maildelivery.R;

public class EditPersonInfo extends AppCompatActivity {

    EditText etFullName, etAge;
    RadioGroup rgGender;
    RadioButton rbMale, rbFemale;
    Spinner spinnerUserEnd, spinnerRoomEnd;
    Button btnConfirm;
    DatabaseReference dataRef;
    String answerGender = "unknown";
    TextView tvSpinnerType, tvSpinnerRoom;
    ImageView ivPersonIcon;

    NfcAdapter nfcAdapter;
    PendingIntent pendingIntent;
    TextView resultNfc;
    Button btnNfc;

    private FirebaseAuth mFirebaseAuth;
    private FirebaseDatabase mFirebaseDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_person_info);

        //set the title in the action bar
        getSupportActionBar().setTitle("BMW Mail Delivery: Personal information");

        //setup use of the spinner to set which kind of user will use the app, and the looks of it.
        Spinner spinnerUser = findViewById(R.id.spinnerTypeUser);
        ArrayAdapter adapterUser = ArrayAdapter.createFromResource(this, R.array.typeUser, R.layout.color_spinner_layout);
        adapterUser.setDropDownViewResource(R.layout.color_spinner_layout);
        spinnerUser.setAdapter(adapterUser);

        //setup use of the spinner to set the location of the room of the user, and the looks of it.
        Spinner spinnerRoom = findViewById(R.id.spinnerLocationUser);
        ArrayAdapter adapterRoom = ArrayAdapter.createFromResource(this, R.array.locationUser, R.layout.color_spinner_layout);
        adapterRoom.setDropDownViewResource(R.layout.color_spinner_layout);
        spinnerRoom.setAdapter(adapterRoom);

        //setting up all the parts to confirm the survey (all the clickable and fill in parts)
        etFullName = (EditText) findViewById(R.id.inputFullName);
        etAge = (EditText) findViewById(R.id.inputAge);
        rgGender = findViewById(R.id.inputGender);
        spinnerUserEnd = (Spinner) findViewById(R.id.spinnerTypeUser);
        spinnerRoomEnd = (Spinner) findViewById(R.id.spinnerLocationUser);
        btnConfirm = (Button) findViewById(R.id.btnConfirmEditPerson);

        rbMale = (RadioButton) findViewById(R.id.radioButtonMale);
        rbFemale = (RadioButton) findViewById(R.id.radioButtonFemale);

        tvSpinnerType = (TextView) findViewById(R.id.textAboveTypeUserSpinner);
        tvSpinnerRoom = (TextView) findViewById(R.id.textAboveRoomUserSpinner);

        resultNfc = (TextView) findViewById(R.id.resultNfc);
        btnNfc = (Button) findViewById(R.id.btnAddNfcScanToAccId);

        //setting up the firebase database to write to the database
        dataRef = FirebaseDatabase.getInstance().getReference("Member");
        //setting up the firebase authentication
        mFirebaseAuth = FirebaseAuth.getInstance();
        //setting up the firebase database to read from the database
        mFirebaseDatabase = FirebaseDatabase.getInstance();

        //This ImageView is just the place holder for uploading a picture; If clicked it sends a toast
        ivPersonIcon = (ImageView)findViewById(R.id.ivPersonIconId);
        ivPersonIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(EditPersonInfo.this, "Not yet implemented", Toast.LENGTH_SHORT).show();
            }
        });

        //start the method for the input to the database by clicking on the confirm button
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addMember();
            }
        });

        //setting up the NFC so that the phone has access to read a nfc card TODO wolf
        pendingIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, this.getClass())
                        .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
    }

    public void addMember() {
        //get the info that the user filled in
        String fullName = etFullName.getText().toString().trim();
        String ageCheck = etAge.getText().toString().trim();
        String gender = answerGender;
        String typeUser = spinnerUserEnd.getSelectedItem().toString();
        String roomUser = spinnerRoomEnd.getSelectedItem().toString();
        String nfcId = resultNfc.getText().toString();

        //get the info out of the authentication, to link auth and database
        String memberUid = Objects.requireNonNull(mFirebaseAuth.getCurrentUser()).getUid();
        String registerEmail = mFirebaseAuth.getCurrentUser().getEmail();

        //do all sorts of checks in order to check the information that is send to the database
        //set an error when something is wrong, so that the user knows what needs to be done
        if (fullName.isEmpty()){
            etFullName.setError("Please enter your name");
            etFullName.requestFocus();
        }
        else if (ageCheck.isEmpty()){
            etAge.setError("Please enter your age");
            etFullName.requestFocus();
        }
        else if (!isInteger(ageCheck)){
            etAge.setError("Please only enter numbers");
            etAge.requestFocus();
        }
        else if (gender.equals("unknown")){
            rbFemale.setError("Please enter your gender");
            rbFemale.requestFocus();
        }
        else if (typeUser.equals("Default")){
            TextView errorText = (TextView)spinnerUserEnd.getSelectedView();
            errorText.setError("icon");
            errorText.setTextColor(Color.RED);
            errorText.setText("Select a user type");
            errorText.requestFocus();
        }
        //if the user loads in packages his room must be default
        else if (typeUser.equals("Load in packages") && !roomUser.equals("Default")){
            TextView errorText = (TextView)spinnerRoomEnd.getSelectedView();
            errorText.setError("icon");
            errorText.setTextColor(Color.RED);
            errorText.setText("Set to default");
            errorText.requestFocus();
        }
        //if the user receives packages the room can not be default
        else if (typeUser.equals("Receive packages") && roomUser.equals("Default")){
            TextView errorText = (TextView)spinnerRoomEnd.getSelectedView();
            errorText.setError("icon");
            errorText.setTextColor(Color.RED);
            errorText.setText("Set location of room");
            errorText.requestFocus();
        }
        //Their must be a nfc card scanned
        else if (nfcId.equals("")){
            btnNfc.setError("Please scan your card");
            resultNfc.requestFocus();
        }
        //when all checks are executed it is time to send the data
        else {
            //age must be converted to a integer (was a string)
            int age = Integer.parseInt(ageCheck);

            //fill in the new member using the Member() class. This class helps to write more data to the database at once
            Member member = new Member(memberUid, fullName, age, typeUser, roomUser, gender, registerEmail, nfcId);

            //push the data to the database with the memberUid as child id
            dataRef.child(memberUid).setValue(member);

            //go to a method that checks wat the next page should be
            goToNextPage();
        }
    }

    //convert the info of the radio button to a string,  used for the gender input
    public String onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();

        switch (view.getId()) {
            case R.id.radioButtonMale:
                if (checked)
                    answerGender = "Male";
                break;
            case R.id.radioButtonFemale:
                if (checked)
                    answerGender = "Female";
                break;
        }
        return answerGender;
    }

    //decide to which home screen the user should be directed to
    private void goToNextPage() {
        //get the UID of the user that is logged in, in firebase auth
        String memberUid = Objects.requireNonNull(mFirebaseAuth.getCurrentUser()).getUid();

        //get the data that belongs to the user that is logged in out of the database
        DatabaseReference mDatabaseRef = mFirebaseDatabase.getReference().child("Member").child(memberUid);

        //make a dataSnapshot
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String userType = dataSnapshot.child("userType").getValue().toString();

                //if the user loads in he should be directed to the Home screen of the sender
                if (userType.equals("Load in packages")){
                    startActivity(new Intent(EditPersonInfo.this, HomeScreenSender.class));
                }
                //if the user receives in he should be directed to the Home screen of the receiver
                else if (userType.equals("Receive packages")){
                    startActivity(new Intent(EditPersonInfo.this, HomeScreenReceiver.class));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    //check if the filled in input is really a integer, used for the age input
    public boolean isInteger(String input) {
        try {
            Integer.parseInt(input);
            return true;
        }
        catch(Exception NumberFormatException ) {
            return false;
        }
    }

    //popup TODO wolf
    public void onNfcButtonClicked(View view){

        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.popup_nfc, null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window tolken
        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        if (nfcAdapter == null) {
            Toast.makeText(this, "No NFC", Toast.LENGTH_SHORT).show();
            //close app when no NFC available
            finish();
            return;
        }

        if (nfcAdapter != null) {
            if (!nfcAdapter.isEnabled())
                showWirelessSettings();

            nfcAdapter.enableForegroundDispatch(this, pendingIntent, null, null);
        }
    }

    //TODO wolf
    private void showWirelessSettings() {
        Toast.makeText(this, "You need to enable NFC", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
        startActivity(intent);
    }

    //TODO wolf
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        resolveIntent(intent);
    }

    //TODO wolf
    private void resolveIntent(Intent intent) {
        String action = intent.getAction();

        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)) {
            Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
            NdefMessage[] msgs;

            if (rawMsgs != null) {
                msgs = new NdefMessage[rawMsgs.length];

                for (int i = 0; i < rawMsgs.length; i++) {
                    msgs[i] = (NdefMessage) rawMsgs[i];
                }

            } else {
                byte[] empty = new byte[0];
                byte[] id = intent.getByteArrayExtra(NfcAdapter.EXTRA_ID);
                Tag tag = (Tag) intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
                byte[] payload = dumpTagData(tag).getBytes();
                NdefRecord record = new NdefRecord(NdefRecord.TNF_UNKNOWN, empty, id, payload);
                NdefMessage msg = new NdefMessage(new NdefRecord[]{record});
                msgs = new NdefMessage[]{msg};
            }

            displayMsgs(msgs);
        }
    }

    //TODO wolf
    private void displayMsgs(NdefMessage[] msgs) {
        if (msgs == null || msgs.length == 0)
            return;

        StringBuilder builder = new StringBuilder();
        List<ParsedNdefRecord> records = NdefMessageParser.parse(msgs[0]);
        final int size = records.size();

        for (int i = 0; i < size; i++) {
            ParsedNdefRecord record = records.get(i);
            String str = record.str();
            builder.append(str);
        }

        resultNfc.setText(builder.toString());
        System.out.println(builder.toString());

    }

    //TODO wolf
    private String dumpTagData(Tag tag){
        StringBuilder sb = new StringBuilder();
        byte[] id = tag.getId();
        sb.append(toHex(id));

        return sb.toString();
    }

    //TODO wolf
    private String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (int i = bytes.length - 1; i >= 0; --i) {
            int b = bytes[i] & 0xff;
            if (b < 0x10)
                sb.append('0');
            sb.append(Integer.toHexString(b));
            if (i > 0) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }
}
