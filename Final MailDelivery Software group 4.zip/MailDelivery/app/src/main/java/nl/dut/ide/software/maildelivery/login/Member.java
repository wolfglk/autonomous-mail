package nl.dut.ide.software.maildelivery.login;

public class Member {

    private String memberUid;
    private String fullName;
    private int age;
    private String userType;
    private String userLocation;
    private String gender;
    private String registerEmail;
    private String nfcId;


    public Member() {
    }

    public Member(String memberUid, String fullName, int age, String userType, String userLocation, String gender, String registerEmail, String nfcId) {
        this.memberUid = memberUid;
        this.fullName = fullName;
        this.age = age;
        this.userType = userType;
        this.userLocation = userLocation;
        this.gender = gender;
        this.registerEmail = registerEmail;
        this.nfcId = nfcId;
    }

    //get asks for the info of the member
    public String getMemberUid() {return memberUid;}
    public String getFullName() {return fullName;}
    public int getAge() {return age;}
    public String getUserType() {return userType;}
    public String getUserLocation() {return userLocation;}
    public String getGender(){return gender;}
    public String getRegisterEmail(){return registerEmail;}
    public String getNfcId(){return nfcId;}

    //set info of member
    public void setMemberUid(String memberUid) {this.memberUid = memberUid;}
    public void setFullName(String fullName) {this.fullName = fullName;}
    public void setAge(int age) {this.age = age;}
    public void setUserType(String userType) {this.userType = userType;}
    public void setUserLocation(String userLocation) {this.userLocation = userLocation;}
    public void setGender(String gender) {this.gender = gender;}
    public void setRegisterEmail(String registerEmail) {this.registerEmail = registerEmail;}
    public void setNfcId(String nfcId) {this.nfcId = nfcId;}
}
