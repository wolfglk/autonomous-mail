package nl.dut.ide.software.maildelivery.QRcode;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;
import com.google.firebase.auth.FirebaseAuth;

import java.io.IOException;

import nl.dut.ide.software.maildelivery.R;
import nl.dut.ide.software.maildelivery.login.Login;
import nl.dut.ide.software.maildelivery.sender.HomeScreenSender;

public class QRScanner extends AppCompatActivity  implements View.OnClickListener{

    SurfaceView surfaceView;
    CameraSource cameraSource;
    BarcodeDetector barcodeDetector;
    TextView tvqrCode;
    Button addButton;
    Button scanButton;
    Button resultButton;
    DatabaseHelper qrDB;
    ImageView ivQRScannerToHomeScreenSender;
    Button btnQRScanLogOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrscanner);

        getSupportActionBar().setTitle("BMW Mail Delivery: Scan packages");

        qrDB = new DatabaseHelper(this);

        surfaceView = (SurfaceView) findViewById(R.id.cameraPreview);
        tvqrCode = (TextView) findViewById(R.id.qrResult);
        addButton = (Button) findViewById(R.id.addButton);
        scanButton = (Button) findViewById(R.id.scanButton);
        resultButton = (Button) findViewById(R.id.resultButton);

        ivQRScannerToHomeScreenSender = (ImageView) findViewById(R.id.ivQRScannerToHomeScreenSenderId);
        btnQRScanLogOut = (Button) findViewById(R.id.btnQRScanLogOutId);

        AddButtonClicked();
        ScanButtonClicked();
        ResultButtonClicked();

        //Initialize Barcode detections for QR-codes only
        barcodeDetector = new BarcodeDetector.Builder(this)
                .setBarcodeFormats(Barcode.QR_CODE)
                .build();

        //Initialize Camera source
        cameraSource = new CameraSource.Builder(this,barcodeDetector)
                .setRequestedPreviewSize(640,480)
                .setFacing(CameraSource.CAMERA_FACING_BACK)
                .setAutoFocusEnabled(true)
                .build();

        surfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                try {
                    if(ContextCompat.checkSelfPermission(QRScanner.this, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED){
                        cameraSource.start(surfaceView.getHolder()); }
                }
                catch(IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                cameraSource.stop();
            }
        });

        //Start barcode detection
        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {

            }

            @Override
            public void receiveDetections(Detector.Detections<Barcode> detections) {
                final SparseArray<Barcode> qrCodes = detections.getDetectedItems();

                //Receive detections and add the value to a textView
                if(qrCodes.size()!=0)
                {
                    tvqrCode.setText(qrCodes.valueAt(0).displayValue);

                    //Stop barcode detection
                    barcodeDetector.release();
                }
            }
        });


    }

    public void AddButtonClicked(){
        //When clicking on Add button add the qr value to the database and clear the textView
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newEntry = tvqrCode.getText().toString();

                if(tvqrCode.length() != 0){
                    AddData(newEntry);
                    tvqrCode.setText("");
                    ScanButtonClickedAgain();
                }
                else{
                    Toast toast = Toast.makeText(QRScanner.this,"First scan a barcode!",Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.BOTTOM, 0, 400);
                    toast.show();
                }
            }
        });
    }

    public void ScanButtonClicked(){
        //Rescan the barcode to get a new value
       scanButton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               tvqrCode.setText("");
               barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
                   @Override
                   public void release() {

                   }

                   @Override
                   public void receiveDetections(Detector.Detections<Barcode> detections) {
                       final SparseArray<Barcode> qrCodes = detections.getDetectedItems();

                       if(qrCodes.size()!=0)
                       {
                           tvqrCode.setText(qrCodes.valueAt(0).displayValue);
                           barcodeDetector.release();
                       }
                   }
               });
           }
       });

    }

    public void ScanButtonClickedAgain(){
        //A method to be able to scan a new barcode as soon as you add a barcode to the list
        tvqrCode.setText("");
        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {

            }

            @Override
            public void receiveDetections(Detector.Detections<Barcode> detections) {
                final SparseArray<Barcode> qrCodes = detections.getDetectedItems();

                if(qrCodes.size()!=0)
                {
                    tvqrCode.setText(qrCodes.valueAt(0).displayValue);
                    barcodeDetector.release();
                }
            }
        });
    }


    @SuppressLint("ResourceAsColor")
    public void AddData (String newEntry){
        //Inserting the value to the database
        boolean insertData = qrDB.addData(newEntry);

        if(insertData == true){
            Toast toast = Toast.makeText(QRScanner.this, "Successfully added to your list", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.BOTTOM, 0, 400);
            toast.show();
        }
        else{
            Toast toast = Toast.makeText(QRScanner.this, "Something went wrong", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.BOTTOM, 0, 400);
            toast.show();
        }
    }

    public void ResultButtonClicked(){
        //Move to the page with the listView
        resultButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Move to the list page
                Intent intent = new Intent(QRScanner.this, QRListContent.class);
                startActivity(intent);
            }
        });
    }


    @Override
    public void onClick(View v){
        if (v.getId() == R.id.btnQRScanLogOutId){
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(QRScanner.this, Login.class));
        }
        else if (v.getId() == R.id.ivQRScannerToHomeScreenSenderId){
            startActivity(new Intent(QRScanner.this, HomeScreenSender.class));
        }
    }


}
