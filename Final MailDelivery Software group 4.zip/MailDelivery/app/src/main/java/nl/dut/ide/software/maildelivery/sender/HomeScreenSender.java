package nl.dut.ide.software.maildelivery.sender;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import nl.dut.ide.software.maildelivery.R;
import nl.dut.ide.software.maildelivery.login.Login;

public class HomeScreenSender extends AppCompatActivity implements View.OnClickListener {

    Button btnLogout;
    Button btnCar1, btnCar2, btnCar3, btnCar4;
    TextView tvCar1, tvCar2, tvCar3, tvCar4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen_sender);

        getSupportActionBar().setTitle("BMW Mail Delivery: Home screen");

        btnLogout = (Button) findViewById(R.id.btnSenderLogOutId);

        btnCar1 = (Button) findViewById(R.id.btnCar1Id);
        btnCar2 = (Button) findViewById(R.id.btnCar2Id);
        btnCar3 = (Button) findViewById(R.id.btnCar3Id);
        btnCar4 = (Button) findViewById(R.id.btnCar4Id);

        tvCar1 = (TextView) findViewById(R.id.tvCar1Id);
        tvCar2 = (TextView) findViewById(R.id.tvCar2Id);
        tvCar3 = (TextView) findViewById(R.id.tvCar3Id);
        tvCar4 = (TextView) findViewById(R.id.tvCar4Id);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED)
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA}, 0);



    }

    @Override
    public void onClick(View v){
        if (v.getId() == R.id.btnCar1Id){
            openPageCar(tvCar1);
        }
        else if (v.getId() == R.id.btnCar2Id){
            openPageCar(tvCar2);
        }
        else if (v.getId() == R.id.btnCar3Id){
            openPageCar(tvCar3);
        }
        else if (v.getId() == R.id.btnCar4Id){
            openPageCar(tvCar4);
        }
        else if (v.getId() == R.id.btnSenderLogOutId){
            logOut();
        }
    }


    private void logOut(){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(HomeScreenSender.this, Login.class));
    }

    private void openPageCar(TextView clickedButton){
        String status = clickedButton.getText().toString().trim();

        if (status.equals("Driving")){
            startActivity(new Intent(HomeScreenSender.this, PlanningSender.class));
        }
        else if (status.equals("Home station")){
            startActivity(new Intent(HomeScreenSender.this, NfcScanSender.class));
        }
        else {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show();
        }
    }


}
