package nl.dut.ide.software.maildelivery.ShortestPathTwoLocations;

import java.util.ArrayList;

public class Pruning {

    //This function prunes the Permutation list by checking for the same option but backwards (halves the list)
    public ArrayList<String> PruningPermutationsList(ArrayList<String> permutationsList){

        //the newly pruned list
        ArrayList<String> prunedList = new ArrayList<>();

        //for loop to step trough all the stings in the permutationsList
        for (int count = 0; count < permutationsList.size(); count++){

            //get the current option and convert it to the backwards option
            String currentPermutation = permutationsList.get(count);
            String currentPermutationBackwards = new StringBuilder(currentPermutation).reverse().toString();

            //if the backwards option is not in the list the normal option should be added
            if (!prunedList.contains(currentPermutationBackwards)){
                prunedList.add(currentPermutation);
            }
        }

        //return the list
        return prunedList;
    }


}
