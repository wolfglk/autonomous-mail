package nl.dut.ide.software.maildelivery.receiver;
import androidx.appcompat.app.AppCompatActivity;
import android.app.PendingIntent;
import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Parcelable;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import java.util.List;
import java.util.Locale;
import nl.dut.ide.software.maildelivery.NFC.parser.NdefMessageParser;
import nl.dut.ide.software.maildelivery.NFC.record.ParsedNdefRecord;
import nl.dut.ide.software.maildelivery.R;
import nl.dut.ide.software.maildelivery.login.Login;
import nl.dut.ide.software.maildelivery.login.Member;

public class NfcScanReceiver extends AppCompatActivity implements View.OnClickListener{
    Button btnLogout;
    ImageView btnBackToHomeScreen;
    TextView countTimer;
    //NFC wolf
    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mFirebaseAuth;
    String nfcResult;
    NfcAdapter nfcAdapter;
    PendingIntent pendingIntent;
    private CountDownTimer countDownTimer;
    private long timeLeftInMilliseconds = 120000;
    private boolean timerRunning;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nfc_scan_receiver);
        getSupportActionBar().setTitle("BMW Mail Delivery: Scan campus card");
        btnBackToHomeScreen = (ImageView) findViewById(R.id.ivNFCToHomeScreenSenderId);
        btnLogout = (Button) findViewById(R.id.btnNfcScanLogOutId);
        countTimer = (TextView) findViewById(R.id.countdownTimer);
        //NFC wolf
        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        //nfcResult = "80 53 c4 22 2e 81 04\n";
        pendingIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, this.getClass())
                        .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        startTimer();
        nfcReader();
    }
    private void startTimer(){
        countDownTimer = new CountDownTimer(timeLeftInMilliseconds, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMilliseconds = millisUntilFinished;
                updateTimer();
            }
            @Override
            public void onFinish() {
            }
        }.start();
        timerRunning = true;
    }
    private void stopTimer() {
        countDownTimer.cancel();
        timerRunning = false;
    }
    private void updateTimer(){
        int minutes = (int) timeLeftInMilliseconds / 60000;
        int seconds = (int) timeLeftInMilliseconds % 60000 / 1000;
        String timeLeftText = String.format(Locale.getDefault(),"%02d:%02d", minutes, seconds);
        countTimer.setText(timeLeftText);
        if(minutes == 0 && seconds == 0){
            startActivity(new Intent(NfcScanReceiver.this, HomeScreenReceiver.class));
        }
    }
    @Override
    public void onClick(View v){
        if (v.getId() == R.id.btnNfcScanLogOutId){
            logOut();
        }
        else if (v.getId()==R.id.ivNFCToHomeScreenSenderId){
            startActivity(new Intent(NfcScanReceiver.this, HomeScreenReceiver.class));
        }
    }
    private void logOut(){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(NfcScanReceiver.this, Login.class));
    }
    //NFC wolf
    public void User() {
        DatabaseReference mFirebaseDatabaseReference = mFirebaseDatabase.getReference();
        Query query = mFirebaseDatabaseReference.child("Member").orderByChild("nfcId").equalTo(nfcResult);
        query.addValueEventListener(valueEventListener);
    }
    ValueEventListener valueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot dataSnapshot) {
            for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                Member member = postSnapshot.getValue(Member.class);
                String nfcId = member.getNfcId();
                String userLocation = member.getUserLocation();
                String memberUid = member.getMemberUid();
                System.out.println(nfcId);
                System.out.println(userLocation);
                System.out.println(memberUid);
                checkAuth(memberUid);
            }
        }
        @Override
        public void onCancelled(DatabaseError databaseError) {
        }
    };
    public void checkAuth(String memberUid){
        String currentUserAuth = mFirebaseAuth.getUid();
        if(memberUid.equals(currentUserAuth)){
            stopTimer();
            Toast.makeText(this, "Package received!", Toast.LENGTH_SHORT).show();
            countTimer.setText("Package received!");
            countTimer.setTextSize(25);
        }
        else{
            Toast.makeText(this, "Current user and campus card are not the same", Toast.LENGTH_SHORT).show();
        }
    }
    public void nfcReader(){
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            Toast.makeText(this, "No NFC", Toast.LENGTH_SHORT).show();
            //close app when no NFC available
            finish();
            return;
        }
        if (nfcAdapter != null) {
            if (!nfcAdapter.isEnabled())
                showWirelessSettings();
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, null, null);
    }
    private void showWirelessSettings() {
        Toast.makeText(this, "You need to enable NFC", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
        startActivity(intent);
    }
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        resolveIntent(intent);
    }
    private void resolveIntent(Intent intent) {
        String action = intent.getAction();
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)) {
            Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
            NdefMessage[] msgs;
            if (rawMsgs != null) {
                msgs = new NdefMessage[rawMsgs.length];
                for (int i = 0; i < rawMsgs.length; i++) {
                    msgs[i] = (NdefMessage) rawMsgs[i];
                }
            } else {
                byte[] empty = new byte[0];
                byte[] id = intent.getByteArrayExtra(NfcAdapter.EXTRA_ID);
                Tag tag = (Tag) intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
                byte[] payload = dumpTagData(tag).getBytes();
                NdefRecord record = new NdefRecord(NdefRecord.TNF_UNKNOWN, empty, id, payload);
                NdefMessage msg = new NdefMessage(new NdefRecord[]{record});
                msgs = new NdefMessage[]{msg};
            }
            displayMsgs(msgs);
        }
    }
    private void displayMsgs(NdefMessage[] msgs) {
        if (msgs == null || msgs.length == 0)
            return;
        StringBuilder builder = new StringBuilder();
        List<ParsedNdefRecord> records = NdefMessageParser.parse(msgs[0]);
        final int size = records.size();
        for (int i = 0; i < size; i++) {
            ParsedNdefRecord record = records.get(i);
            String str = record.str();
            builder.append(str);
        }
        nfcResult = builder.toString();
        User();
    }
    private String dumpTagData(Tag tag){
        StringBuilder sb = new StringBuilder();
        byte[] id = tag.getId();
        sb.append(toHex(id));
        return sb.toString();
    }
    private String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (int i = bytes.length - 1; i >= 0; --i) {
            int b = bytes[i] & 0xff;
            if (b < 0x10)
                sb.append('0');
            sb.append(Integer.toHexString(b));
            if (i > 0) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }
}