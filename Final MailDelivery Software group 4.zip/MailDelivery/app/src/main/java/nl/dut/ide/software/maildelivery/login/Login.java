package nl.dut.ide.software.maildelivery.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import nl.dut.ide.software.maildelivery.receiver.HomeScreenReceiver;
import nl.dut.ide.software.maildelivery.sender.HomeScreenSender;
import nl.dut.ide.software.maildelivery.R;

public class Login extends AppCompatActivity implements View.OnClickListener {

    EditText etEmail, etPassword;
    Button btnLogin;
    TextView tvForgetPassword, tvOpenRegister;

    private FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;
    private FirebaseDatabase mFirebaseDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        getSupportActionBar().setTitle("BMW Mail Delivery: Login");

        //setting up the firebase, email, password, loginButton
        etEmail = (EditText) findViewById(R.id.etInputEmailIdLogin);
        etPassword = (EditText) findViewById(R.id.etInputPasswordIdLogin);

        btnLogin = (Button) findViewById(R.id.btnLoginId);

        tvForgetPassword = (TextView) findViewById(R.id.tvForgetPasswordId);
        tvOpenRegister = (TextView) findViewById(R.id.tvRegisterId);

        btnLogin.setOnClickListener(this);
        tvForgetPassword.setOnClickListener(this);
        tvOpenRegister.setOnClickListener(this);

        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = mFirebaseAuth.getCurrentUser();
                if (mFirebaseUser != null){
                    isUser();
                    //startActivity(new Intent(Login.this, HomeScreenSender.class));
                }

                /*
                else {
                    Toast toast = Toast.makeText(Login.this, "Please login", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.BOTTOM, 0, 100);
                    toast.show();
                }

                 */
            }
        };
    }

    @Override
    protected void onStart() {
        super.onStart();
        //mFirebaseAuth.addAuthStateListener(mAuthStateListener);
    }

    @Override
    public void onClick (View v){
        if (v.getId() == R.id.tvForgetPasswordId){
            openForgetPassword();
        }
        else if (v.getId() == R.id.btnLoginId){
            loginUser();
        }
        else if (v.getId() == R.id.tvRegisterId){
            openRegister();
        }
    }

    private void loginUser(){
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        //check if the user filled in everything (backwards because email error should occur first)
        if (password.isEmpty()) {
            etPassword.setError("Please enter password");
            etPassword.requestFocus();
        }
        if (email.isEmpty()){
            etEmail.setError("Please enter email");
            etEmail.requestFocus();
        }

        //if all things are filled in
        if (!email.isEmpty() && !password.isEmpty()){
            mFirebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (!task.isSuccessful()){
                        Toast.makeText(Login.this, "Authentication failed: " + task.getException(), Toast.LENGTH_LONG).show();
                        /*
                        Toast toast = Toast.makeText(Login.this, "Login error, please try again", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.BOTTOM, 0, 100);
                        toast.show();
                         */
                    }
                    else {
                        isUser();
                        //Intent intToHomeScreen = new Intent(Login.this, HomeScreenSender.class);
                        //startActivity(intToHomeScreen);
                    }
                }
            });
        }
    }

    private void isUser(){
        String memberUid = Objects.requireNonNull(mFirebaseAuth.getCurrentUser()).getUid();
        DatabaseReference mDatabaseRef = mFirebaseDatabase.getReference().child("Member").child(memberUid);

        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String userType = dataSnapshot.child("userType").getValue().toString();

                if (userType.equals("Load in packages")){
                    startActivity(new Intent(Login.this, HomeScreenSender.class));
                }
                else if (userType.equals("Receive packages")){
                    startActivity(new Intent(Login.this, HomeScreenReceiver.class));
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void openForgetPassword(){
        Toast.makeText(Login.this, "Not yet implemented", Toast.LENGTH_SHORT).show();
    }

    private void openRegister(){
        startActivity(new Intent(this, Register.class));
    }
}
