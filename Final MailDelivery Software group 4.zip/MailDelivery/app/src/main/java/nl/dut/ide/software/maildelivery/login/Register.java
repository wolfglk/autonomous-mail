package nl.dut.ide.software.maildelivery.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

import nl.dut.ide.software.maildelivery.R;

public class Register extends AppCompatActivity implements View.OnClickListener {

    FirebaseAuth mFirebaseAuth;
    EditText etEmail, etPassword, etPasswordCheck;
    Button btnRegister;
    ImageView ivBackToLoginPage;
    TextView tvBackToLoginPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        getSupportActionBar().setTitle("BMW Mail Delivery: Register");

        //setting up firebase
        mFirebaseAuth = FirebaseAuth.getInstance();

        //setting up the email, password, passwordCheck, registerButton
        etEmail = (EditText) findViewById(R.id.etInputEmailId);
        etPassword = (EditText) findViewById(R.id.etInputPasswordId);
        etPasswordCheck = (EditText) findViewById(R.id.etInputPasswordCheckId);

        //setting up what happens when the clickable parts get clicked
        btnRegister = (Button) findViewById(R.id.btnRegisterId);
        ivBackToLoginPage = (ImageView) findViewById(R.id.ivBackToLoginPageId);
        tvBackToLoginPage = (TextView) findViewById(R.id.tvBackToLoginPageId);

        btnRegister.setOnClickListener(this);
        ivBackToLoginPage.setOnClickListener(this);
        tvBackToLoginPage.setOnClickListener(this);

    }

    @Override
    public void onClick(View v){
        if (v.getId() == R.id.ivBackToLoginPageId ){
            backToLastPage();
        }
        else if (v.getId() == R.id.tvBackToLoginPageId){
            backToLastPage();
        }
        else if (v.getId() == R.id.btnRegisterId){
            registerUser();
        }
    }

    public void registerUser(){
        String email = etEmail.getText().toString();
        String password = etPassword.getText().toString();
        String passwordCheck = etPasswordCheck.getText().toString();

        //check if the user filled in everything (backwards because email error should occur first)
        if (passwordCheck.isEmpty()){
            etPasswordCheck.setError("Please re-enter password");
            etPasswordCheck.requestFocus();
        }
        if (password.isEmpty()) {
            etPassword.setError("Please enter password");
            etPassword.requestFocus();
        }
        if (email.isEmpty()){
            etEmail.setError("Please enter email");
            etEmail.requestFocus();
        }

        //if all things are filled in
        if (!email.isEmpty() && !password.isEmpty() && !passwordCheck.isEmpty()){

            // //check if both passwords are the same, register if everything is correct,
            if (!password.equals(passwordCheck)){
                etPasswordCheck.setError("Passwords are not the same");
                etPasswordCheck.requestFocus();
            }
            else {
                mFirebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (!task.isSuccessful()){
                            Toast toast = Toast.makeText(Register.this, "Registration unsuccessful, please try again", Toast.LENGTH_SHORT);
                            toast.setGravity(Gravity.BOTTOM, 0, 100);
                            toast.show();
                        }
                        else {
                            startActivity(new Intent(Register.this, EditPersonInfo.class));
                        }
                    }
                });
            }
        }
    }

    private void backToLastPage(){
        startActivity(new Intent(this, Login.class));
    }

}
