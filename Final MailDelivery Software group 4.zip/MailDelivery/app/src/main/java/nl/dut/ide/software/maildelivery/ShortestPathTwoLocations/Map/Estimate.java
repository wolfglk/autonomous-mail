/*
Estimate calculates straight-line distance between two points.
Estimate is used by A* algorithm to guide search.
 */

package nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Map;

import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Scorer;

public class Estimate implements Scorer<Location> {

    @Override
    public double computeCost(Location from, Location to) {

        double dX = Math.abs(Math.pow((from.getX() - to.getX()), 2));
        double dY = Math.abs(Math.pow((from.getY() - to.getY()), 2));

        double estimate = Math.sqrt(dX + dY);

        return estimate;
    }
}
