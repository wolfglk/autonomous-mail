/*
Java program to print all the permutations of the given STRING.
Retrieved from: https://www.geeksforgeeks.org/print-all-permutations-of-a-string-in-java/

IF BETTER, FIND PERMUTATION FUNCTION FOR ARRAYS

 TO DO:
 1. done      Get delivery addresses from database (ListView).
 2.       Add start + finish, ABC --> SABCS
 3.       Calculate  permutations, (store in database?).
 4.       Split permutations in couples SABCS --> S to A, A to B, B to C, C to A.
 5.1      Let A* run on all couples for one permutation
 5.2      Repeat for all permutations
 6.       Store shortest paths from every permutations
 5.       Convert shortest paths to distances
 6.       Choose minimum distance and convert back to final path
 7.       Export final path to Laurens' Notification feature (output = list?)
 */


package nl.dut.ide.software.maildelivery.ShortestPathTwoLocations;


import java.util.ArrayList;

public class Permutations {

    private String finalAnswerString = "";

    // Function to print all the distinct permutations of str
    public String printDistinctPermutn(String str, String ans){

        // If string is empty
        if (str.length() == 0) {
            //always first and last add the "s" because the car starts and stops at "s"
            finalAnswerString = finalAnswerString + "s" + ans + "s" + " ";
        }

        // Make a boolean array of size '26' which stores false by default
        // and make true at the position which alphabet is being used.
        boolean alpha[] = new boolean[26];

        //loop trough the string
        for (int i = 0; i < str.length(); i++) {

            // ith character of str
            char ch = str.charAt(i);

            // Rest of the string after excluding the ith character
            String ros = str.substring(0, i) + str.substring(i + 1);

            // If the character has not been used then recursive call will take place.
            // Otherwise, there will be no recursive call
            if (alpha[ch - 'a'] == false)
                printDistinctPermutn(ros, ans + ch);
            alpha[ch - 'a'] = true;
        }

        //return the
        return finalAnswerString;
    }



}