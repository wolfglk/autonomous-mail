package nl.dut.ide.software.maildelivery.receiver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import nl.dut.ide.software.maildelivery.R;
import nl.dut.ide.software.maildelivery.login.Login;
import nl.dut.ide.software.maildelivery.sender.HomeScreenSender;
import nl.dut.ide.software.maildelivery.sender.PlanningSender;

public class PlanningReceiver extends AppCompatActivity implements View.OnClickListener {

    Button btnLogout;
    ImageView ivBackToHome;

    //HashMap to store all the imageViews
    HashMap<String, ImageView> imageViews = new HashMap<>();

    String currentUid;
    String uidLocation;

    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mFirebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planning_receiver);

        getSupportActionBar().setTitle("BMW Mail Delivery: Vehicle on route");

        btnLogout = (Button) findViewById(R.id.btnPlanningReceiverLogOutId);
        ivBackToHome = (ImageView) findViewById(R.id.ivPlanningReceiverToHomeScreenId);

        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mFirebaseAuth = FirebaseAuth.getInstance();

        //set all the imageViews for the visual
        ImageView imageView_s_to_a = (ImageView) findViewById(R.id.s_to_aIvRCId);
        imageViews.put("imageView_s_to_a", imageView_s_to_a);
        ImageView imageView_a_to_s = (ImageView) findViewById(R.id.a_to_sIvRCId);
        imageViews.put("imageView_a_to_s", imageView_a_to_s);
        ImageView imageView_a_to_c = (ImageView) findViewById(R.id.a_to_cIvRCId);
        imageViews.put("imageView_a_to_c", imageView_a_to_c);
        ImageView imageView_c_to_a = (ImageView) findViewById(R.id.c_to_aIvRCId);
        imageViews.put("imageView_c_to_a", imageView_c_to_a);
        ImageView imageView_s_to_b = (ImageView) findViewById(R.id.s_to_bIvRCId);
        imageViews.put("imageView_s_to_b", imageView_s_to_b);
        ImageView imageView_b_to_s = (ImageView) findViewById(R.id.b_to_sIvRCId);
        imageViews.put("imageView_b_to_s", imageView_b_to_s);
        ImageView imageView_b_to_c = (ImageView) findViewById(R.id.b_to_cIvRCId);
        imageViews.put("imageView_b_to_c", imageView_b_to_c);
        ImageView imageView_c_to_b = (ImageView) findViewById(R.id.c_to_bIvRCId);
        imageViews.put("imageView_c_to_b", imageView_c_to_b);
        ImageView imageView_c_to_d = (ImageView) findViewById(R.id.c_to_dIvRCId);
        imageViews.put("imageView_c_to_d", imageView_c_to_d);
        ImageView imageView_d_to_c = (ImageView) findViewById(R.id.d_to_cIvRCId);
        imageViews.put("imageView_d_to_c", imageView_d_to_c);
        ImageView imageView_d_to_e = (ImageView) findViewById(R.id.d_to_eIvRCId);
        imageViews.put("imageView_d_to_e", imageView_d_to_e);
        ImageView imageView_e_to_d = (ImageView) findViewById(R.id.e_to_dIvRCId);
        imageViews.put("imageView_e_to_d", imageView_e_to_d);
        ImageView imageView_e_to_g = (ImageView) findViewById(R.id.e_to_gIvRCId);
        imageViews.put("imageView_e_to_g", imageView_e_to_g);
        ImageView imageView_g_to_e = (ImageView) findViewById(R.id.g_to_eIvRCId);
        imageViews.put("imageView_g_to_e", imageView_g_to_e);
        ImageView imageView_f_to_g = (ImageView) findViewById(R.id.f_to_gIvRCId);
        imageViews.put("imageView_f_to_g", imageView_f_to_g);
        ImageView imageView_g_to_f = (ImageView) findViewById(R.id.g_to_fIvRCId);
        imageViews.put("imageView_g_to_f", imageView_g_to_f);
        ImageView imageView_f_to_d = (ImageView) findViewById(R.id.f_to_dIvRCId);
        imageViews.put("imageView_f_to_d", imageView_f_to_d);
        ImageView imageView_d_to_f = (ImageView) findViewById(R.id.d_to_fIvRCId);
        imageViews.put("imageView_d_to_f", imageView_d_to_f);
        ImageView imageView_f_to_b = (ImageView) findViewById(R.id.f_to_bIvRCId);
        imageViews.put("imageView_f_to_b", imageView_f_to_b);
        ImageView imageView_b_to_f = (ImageView) findViewById(R.id.b_to_fIvRCId);
        imageViews.put("imageView_b_to_f", imageView_b_to_f);


        currentUid = mFirebaseAuth.getUid();
        DatabaseReference mDatabaseReff = mFirebaseDatabase.getReference().child("Member").child(currentUid);
        mDatabaseReff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                uidLocation = dataSnapshot.child("userLocation").getValue().toString().toLowerCase();

                GetData(uidLocation);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnPlanningReceiverLogOutId) {
            logOut();
        } else if (v.getId() == R.id.ivPlanningReceiverToHomeScreenId) {
            startActivity(new Intent(PlanningReceiver.this, HomeScreenReceiver.class));
        }
    }

    private void logOut() {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(PlanningReceiver.this, Login.class));
    }

    //
    private void GetData(String uidLocationTwo) {

        DatabaseReference mDatabaseRef = mFirebaseDatabase.getReference().child("Vehicles").child("Vehicle 2");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                String routeStringList = dataSnapshot.child("routeString").getValue().toString();
                String routeString = routeStringList.substring(1, routeStringList.length()-1);
                ArrayList<String> route = new ArrayList<String>(Arrays.asList(routeString.split(", ")));

                String currentLocation = dataSnapshot.child("currentLocation").getValue().toString();

                String dropOffLocationsStringList = dataSnapshot.child("dropOffLocations").getValue().toString();
                String dropOffLocationsString = dropOffLocationsStringList.substring(1, dropOffLocationsStringList.length()-1);
                ArrayList<String> dropOffLocations = new ArrayList<String>(Arrays.asList(dropOffLocationsString.split(", ")));

                CreateMap(route, currentLocation);

                SendMessage(currentLocation, dropOffLocations, uidLocationTwo);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    //set the track the cat is now riding visible
    private void CreateMap(ArrayList<String> route, String location) {

        ImageView imageView_s_to_a = (ImageView) findViewById(R.id.s_to_aIvRCId);
        imageView_s_to_a.setVisibility(View.INVISIBLE);
        ImageView imageView_a_to_s = (ImageView) findViewById(R.id.a_to_sIvRCId);
        imageView_a_to_s.setVisibility(View.INVISIBLE);
        ImageView imageView_a_to_c = (ImageView) findViewById(R.id.a_to_cIvRCId);
        imageView_a_to_c.setVisibility(View.INVISIBLE);
        ImageView imageView_c_to_a = (ImageView) findViewById(R.id.c_to_aIvRCId);
        imageView_c_to_a.setVisibility(View.INVISIBLE);
        ImageView imageView_s_to_b = (ImageView) findViewById(R.id.s_to_bIvRCId);
        imageView_s_to_b.setVisibility(View.INVISIBLE);
        ImageView imageView_b_to_s = (ImageView) findViewById(R.id.b_to_sIvRCId);
        imageView_b_to_s.setVisibility(View.INVISIBLE);
        ImageView imageView_b_to_c = (ImageView) findViewById(R.id.b_to_cIvRCId);
        imageView_b_to_c.setVisibility(View.INVISIBLE);
        ImageView imageView_c_to_b = (ImageView) findViewById(R.id.c_to_bIvRCId);
        imageView_c_to_b.setVisibility(View.INVISIBLE);
        ImageView imageView_c_to_d = (ImageView) findViewById(R.id.c_to_dIvRCId);
        imageView_c_to_d.setVisibility(View.INVISIBLE);
        ImageView imageView_d_to_c = (ImageView) findViewById(R.id.d_to_cIvRCId);
        imageView_d_to_c.setVisibility(View.INVISIBLE);
        ImageView imageView_d_to_e = (ImageView) findViewById(R.id.d_to_eIvRCId);
        imageView_d_to_e.setVisibility(View.INVISIBLE);
        ImageView imageView_e_to_d = (ImageView) findViewById(R.id.e_to_dIvRCId);
        imageView_e_to_d.setVisibility(View.INVISIBLE);
        ImageView imageView_e_to_g = (ImageView) findViewById(R.id.e_to_gIvRCId);
        imageView_e_to_g.setVisibility(View.INVISIBLE);
        ImageView imageView_g_to_e = (ImageView) findViewById(R.id.g_to_eIvRCId);
        imageView_g_to_e.setVisibility(View.INVISIBLE);
        ImageView imageView_f_to_g = (ImageView) findViewById(R.id.f_to_gIvRCId);
        imageView_f_to_g.setVisibility(View.INVISIBLE);
        ImageView imageView_g_to_f = (ImageView) findViewById(R.id.g_to_fIvRCId);
        imageView_g_to_f.setVisibility(View.INVISIBLE);
        ImageView imageView_f_to_d = (ImageView) findViewById(R.id.f_to_dIvRCId);
        imageView_f_to_d.setVisibility(View.INVISIBLE);
        ImageView imageView_d_to_f = (ImageView) findViewById(R.id.d_to_fIvRCId);
        imageView_d_to_f.setVisibility(View.INVISIBLE);
        ImageView imageView_f_to_b = (ImageView) findViewById(R.id.f_to_bIvRCId);
        imageView_f_to_b.setVisibility(View.INVISIBLE);
        ImageView imageView_b_to_f = (ImageView) findViewById(R.id.b_to_fIvRCId);
        imageView_b_to_f.setVisibility(View.INVISIBLE);

        int indexLocation = route.indexOf(location);
        int size = route.size();

        ArrayList<String> toDo = new ArrayList<>();

        for (int count = indexLocation; count < size; count++){
            toDo.add(route.get(count));
        }

        String fromStation = toDo.get(0);
        String toStation = toDo.get(1);

        String fromToString = "imageView_" + fromStation + "_to_" + toStation;

        ImageView blinkingImageView = imageViews.get(fromToString);

        blinkingImageView.setVisibility(View.VISIBLE);
    }

    private void SendMessage(String currentLocation, ArrayList<String> dropOffLocations, String uidLocationThree){

        for (int count = 0; count < dropOffLocations.size(); count++){
            String dropOffLocation = dropOffLocations.get(count);

            if (dropOffLocation.equals(currentLocation)){

                if (uidLocationThree.equals(currentLocation)) {
                    startActivity(new Intent(PlanningReceiver.this, NfcScanReceiver.class));
                }
                else {
                    break;
                }

            }

        }

    }


}
