package nl.dut.ide.software.maildelivery.sender;

import java.util.ArrayList;

public class Vehicle {

    public ArrayList<String> routeSteps;
    public String routeString;

    public Vehicle() {
        // Default constructor required for calls to DataSnapshot.getValue(Vehicle.class)
    }

    public Vehicle(ArrayList<String> routeSteps, String routeString) {
        this.routeSteps = routeSteps;
        this.routeString = routeString;
    }

    public ArrayList<String> getRouteSteps() {return routeSteps;}
    public String getRouteString() {return routeString;}

    public void setRouteSteps(ArrayList<String> routeSteps) {this.routeSteps = routeSteps;}
    public void setRouteString(String routeString) {this.routeString = routeString;}

}
