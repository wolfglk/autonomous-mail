/*
AStarAlgoritm generates routes across the graph.
Uses Graph, exact score to next node, and the estimated score to destination.

AStarAlgoritm" takes start and end node and computes best route between the two.
 */

package nl.dut.ide.software.maildelivery.ShortestPathTwoLocations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.stream.Collectors;

//
public class AStarAlgoritm<T extends GraphNode> {
    private final Graph<T> graph;
    private final Scorer<T> nextNodeScorer;
    private final Scorer<T> targetScorer;

    public AStarAlgoritm(Graph<T> graph, Scorer<T> nextNodeScorer, Scorer<T> targetScorer) {
        this.graph = graph;
        this.nextNodeScorer = nextNodeScorer;
        this.targetScorer = targetScorer;
    }

    public List<T> findRoute(T from, T to) {
        // "open set" of nodes that can be the next step
        // PriorityQueue for open set gets best entry of it based on compareTo() in Scorer
        Queue<RouteNode> openSet = new PriorityQueue<>();

        Map<T, RouteNode<T>> allNodes = new HashMap<>();    // map of every visited node

        //start node has score null
        RouteNode<T> start = new RouteNode<>(from, null, 0d, targetScorer.computeCost(from, to));
        allNodes.put(from, start);
        openSet.add(start);


        //Iterate until (1) best available node is destination or (2) run out of nodes
        // Backtrack previous node until starting point is reached
        while (!openSet.isEmpty()) {
            //System.out.println("Open Set contains: " + openSet.stream().map(RouteNode::getCurrent).collect(Collectors.toSet()));
            RouteNode<T> next = openSet.poll();
            //System.out.println("Looking at node: " + next);
            if (next.getCurrent().equals(to)) {
                //System.out.println("Found our destination!");

                List<T> route = new ArrayList<>();
                RouteNode<T> current = next;
                do {
                    route.add(0, current.getCurrent());
                    current = allNodes.get(current.getPrevious());
                } while (current != null);

                //System.out.println("Route: " + route);
                return route;
            }

            // Iterating over connected nodes from graph.
            // For each of these get RouteNode or a new one is created
            graph.  getConnections(next.getCurrent()).forEach(connection -> {
                double newScore = next.getRouteScore() + nextNodeScorer.computeCost(next.getCurrent(), connection);
                RouteNode<T> nextNode = allNodes.getOrDefault(connection, new RouteNode<>(connection));
                allNodes.put(connection, nextNode);

                //Computing new score for node and see if it's cheaper.
                //If so, it's updated to match new route and added to open set for consideration next time around.
                if (nextNode.getRouteScore() > newScore) {
                    nextNode.setPrevious(next.getCurrent());
                    nextNode.setRouteScore(newScore);
                    nextNode.setEstimatedScore(newScore + targetScorer.computeCost(connection, to));
                    openSet.add(nextNode);
                    //System.out.println("Found a better route to node: " + nextNode);
                }
            });
        }

        //Run out of nodes
        throw new IllegalStateException("No route found");
    }

}