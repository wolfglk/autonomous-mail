package nl.dut.ide.software.maildelivery.sender;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import nl.dut.ide.software.maildelivery.R;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Graph;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Map.Estimate;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Map.Location;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Test;
import nl.dut.ide.software.maildelivery.login.EditPersonInfo;
import nl.dut.ide.software.maildelivery.login.Login;
import nl.dut.ide.software.maildelivery.receiver.HomeScreenReceiver;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.AStarAlgoritm;

public class PlanningSender extends AppCompatActivity implements View.OnClickListener {

    Button btnLogout;
    ImageView ivBackToHome;

    int timerCar;

    //HashMap to store all the imageViews
    HashMap<String, ImageView> imageViews = new HashMap<>();

    private FirebaseDatabase mFirebaseDatabase;

    Test testAStar;
    Estimate estimateDistance;
    Graph<Location> map;
    AStarAlgoritm aStarAlgoritm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planning_sender);

        btnLogout = (Button) findViewById(R.id.btnPlanningSenderLogOutId);
        ivBackToHome = (ImageView) findViewById(R.id.ivPlanningSenderToHomeScreenId);

        mFirebaseDatabase = FirebaseDatabase.getInstance();

        //set all the imageViews for the visual
        ImageView imageView_s_to_a = (ImageView) findViewById(R.id.s_to_aIvRCId);
        imageViews.put("imageView_s_to_a", imageView_s_to_a);
        ImageView imageView_a_to_s = (ImageView) findViewById(R.id.a_to_sIvRCId);
        imageViews.put("imageView_a_to_s", imageView_a_to_s);
        ImageView imageView_a_to_c = (ImageView) findViewById(R.id.a_to_cIvRCId);
        imageViews.put("imageView_a_to_c", imageView_a_to_c);
        ImageView imageView_c_to_a = (ImageView) findViewById(R.id.c_to_aIvRCId);
        imageViews.put("imageView_c_to_a", imageView_c_to_a);
        ImageView imageView_s_to_b = (ImageView) findViewById(R.id.s_to_bIvRCId);
        imageViews.put("imageView_s_to_b", imageView_s_to_b);
        ImageView imageView_b_to_s = (ImageView) findViewById(R.id.b_to_sIvRCId);
        imageViews.put("imageView_b_to_s", imageView_b_to_s);
        ImageView imageView_b_to_c = (ImageView) findViewById(R.id.b_to_cIvRCId);
        imageViews.put("imageView_b_to_c", imageView_b_to_c);
        ImageView imageView_c_to_b = (ImageView) findViewById(R.id.c_to_bIvRCId);
        imageViews.put("imageView_c_to_b", imageView_c_to_b);
        ImageView imageView_c_to_d = (ImageView) findViewById(R.id.c_to_dIvRCId);
        imageViews.put("imageView_c_to_d", imageView_c_to_d);
        ImageView imageView_d_to_c = (ImageView) findViewById(R.id.d_to_cIvRCId);
        imageViews.put("imageView_d_to_c", imageView_d_to_c);
        ImageView imageView_d_to_e = (ImageView) findViewById(R.id.d_to_eIvRCId);
        imageViews.put("imageView_d_to_e", imageView_d_to_e);
        ImageView imageView_e_to_d = (ImageView) findViewById(R.id.e_to_dIvRCId);
        imageViews.put("imageView_e_to_d", imageView_e_to_d);
        ImageView imageView_e_to_g = (ImageView) findViewById(R.id.e_to_gIvRCId);
        imageViews.put("imageView_e_to_g", imageView_e_to_g);
        ImageView imageView_g_to_e = (ImageView) findViewById(R.id.g_to_eIvRCId);
        imageViews.put("imageView_g_to_e", imageView_g_to_e);
        ImageView imageView_f_to_g = (ImageView) findViewById(R.id.f_to_gIvRCId);
        imageViews.put("imageView_f_to_g", imageView_f_to_g);
        ImageView imageView_g_to_f = (ImageView) findViewById(R.id.g_to_fIvRCId);
        imageViews.put("imageView_g_to_f", imageView_g_to_f);
        ImageView imageView_f_to_d = (ImageView) findViewById(R.id.f_to_dIvRCId);
        imageViews.put("imageView_f_to_d", imageView_f_to_d);
        ImageView imageView_d_to_f = (ImageView) findViewById(R.id.d_to_fIvRCId);
        imageViews.put("imageView_d_to_f", imageView_d_to_f);
        ImageView imageView_f_to_b = (ImageView) findViewById(R.id.f_to_bIvRCId);
        imageViews.put("imageView_f_to_b", imageView_f_to_b);
        ImageView imageView_b_to_f = (ImageView) findViewById(R.id.b_to_fIvRCId);
        imageViews.put("imageView_b_to_f", imageView_b_to_f);

        //setup the A* algorithm tester and estimate distance calculator
        testAStar = new Test();
        estimateDistance = new Estimate();

        //setup the A* tester setup
        try {
            testAStar.setUp();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //Setup of the coordinates, connections
        Set<Location> locations = new HashSet<Location>();
        Map<String, Set<String>> connections = new HashMap<>();

        //Coordinates
        locations.add(new Location("s", "s", 1.63, 0));
        locations.add(new Location("a", "a", 2.265, 2.97));
        locations.add(new Location("b", "b", 1.00, 6.95));
        locations.add(new Location("c", "c", 2.265, 9.42));
        locations.add(new Location("d", "d", 2.265, 15.48));
        locations.add(new Location("e", "e", 2.265, 19.19));
        locations.add(new Location("f", "f", 1.00, 19.39));
        locations.add(new Location("g", "g", 2.265, 22.43));

        //Connections
        connections.put("s", Stream.of("a", "b").collect(Collectors.toSet()));
        connections.put("a", Stream.of("s", "c").collect(Collectors.toSet()));
        connections.put("b", Stream.of("s", "c", "f").collect(Collectors.toSet()));
        connections.put("c", Stream.of("a", "b", "d").collect(Collectors.toSet()));
        connections.put("d", Stream.of("c", "f", "e").collect(Collectors.toSet()));
        connections.put("e", Stream.of("d", "g").collect(Collectors.toSet()));
        connections.put("f", Stream.of("d", "g", "b").collect(Collectors.toSet()));
        connections.put("g", Stream.of("e", "f").collect(Collectors.toSet()));

        //map
        map = new Graph<Location>(locations, connections);

        //A* algorithm
        aStarAlgoritm = new AStarAlgoritm<Location>(map, new Estimate(), new Estimate());

        GetData();

    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnPlanningSenderLogOutId) {
            logOut();
        } else if (v.getId() == R.id.ivPlanningSenderToHomeScreenId) {
            startActivity(new Intent(PlanningSender.this, HomeScreenSender.class));
        }
    }


    private void logOut() {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(PlanningSender.this, Login.class));
    }


    private void CreateMap(ArrayList<String> route, String location) {

        System.out.println(route);
        System.out.println(location);

        int indexLocation = route.indexOf(location);
        int size = route.size();
        int speed = 2; // meters per second

        ArrayList<String> done = new ArrayList<>();
        ArrayList<String> toDo = new ArrayList<>();

        for (int count = 0; count < indexLocation + 1; count++){
            done.add(route.get(count));
        }

        for (int count = indexLocation; count < size; count++){
            toDo.add(route.get(count));
        }

        System.out.println(done);
        System.out.println(toDo);

        ArrayList<Integer> timerCarList = new ArrayList<>();
        for (int count = 0; count < toDo.size() -1 ; count++){
            String from = toDo.get(count);
            String to = toDo.get(count+1);

            double distance = DistanceCalculator(from, to);

            timerCar = ((int) Math.round(distance) / speed) * 1000;


            if (count == 0){
                timerCarList.add(timerCar);
            }
            else if (count == 1){
                timerCarList.add(timerCar + 1000);
            }
            else if (count == 2){
                timerCarList.add(timerCar - 3000);
            }
            else {
                timerCarList.add(timerCar);
            }

        }


        Handler handler1 = new Handler();
        for (int count = 0; count < toDo.size() -1 ; count++){
            int finalCount = count;
            handler1.postDelayed(new Runnable() {
                @Override
                public void run() {

                    String from = toDo.get(finalCount);
                    String to = toDo.get(finalCount+1);

                    double distance = DistanceCalculator(from, to);

                    System.out.println("distance of "+ from+ " to "+ to+" = "+distance);

                    timerCar = ((int) Math.round(distance) / speed) * 1000;
                    System.out.println(timerCar);

                    String fromToString = "imageView_" + from + "_to_" + to;

                    imageViews.get(fromToString).setVisibility(View.VISIBLE);

                    Handler handler3 = new Handler();
                    handler3.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            imageViews.get(fromToString).setVisibility(View.INVISIBLE);
                        }
                    },  timerCarList.get(finalCount) ); // timerCarList.get(finalCount) //timerCar
                }
            }, timerCarList.get(count) * count);
        }
    }


    //decide to what page the user should go
    private void GetData() {
        DatabaseReference mDatabaseRef = mFirebaseDatabase.getReference().child("Vehicles").child("Vehicle 3");
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                String routeStringList = dataSnapshot.child("routeString").getValue().toString();

                String routeString = routeStringList.substring(1, routeStringList.length()-1);

                ArrayList<String> route = new ArrayList<String>(Arrays.asList(routeString.split(", ")));

                String currentLocation = dataSnapshot.child("currentLocation").getValue().toString();

                CreateMap(route, currentLocation);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    //function to calculate the distance of an ArrayList and return a double
    public double DistanceCalculator(String stationFrom, String stationTo){
        //the final distance set as a double variable
        double distance = 0.0;

        String stationA = stationFrom;
        String stationB = stationTo;

        //build a list of locations out of the already existing list using the aStarAlgoritm class its function find route
        // We will just pass on two stations that are connected to each other so the shortest route is always that route
        List<Location> locationsList = aStarAlgoritm.findRoute(map.getNode(stationA), map.getNode(stationB));

        //build a location variable that holds all the information about the location
        Location location = locationsList.remove(0);

        distance += new Estimate().computeCost(location, locationsList.get(0));

        //return the final distance
        return distance;
    }





}
