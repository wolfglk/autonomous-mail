package nl.dut.ide.software.maildelivery.sender;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import nl.dut.ide.software.maildelivery.R;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.AStarAlgoritm;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Graph;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Map.Location;
import nl.dut.ide.software.maildelivery.QRcode.DatabaseHelper;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Permutations;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Test;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Map.Estimate;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Pruning;

public class RouteCalculator extends AppCompatActivity implements View.OnClickListener {

    //just for testing
    String testInputPermutations;

    ArrayList<String> resultList;
    String inputPermutations;
    String allPermutationsString;
    ArrayList<String> inputPruning;
    ArrayList<String> inputAlgorithm;

    TextView tvFinalRoute;
    Button btnHomeScreen;
    Button btnRouteCar;

    //HashMap to store all the imageViews
    HashMap<String, ImageView> imageViews = new HashMap<>();

    //classes
    Permutations permutations;
    Pruning pruning;
    DatabaseHelper qrDB;
    Test testAStar;
    Estimate estimateDistance;
    Graph<Location> map;
    AStarAlgoritm aStarAlgoritm;

    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_route_calculator);

        //set text view and buttons
        tvFinalRoute = (TextView) findViewById(R.id.tvFinalRouteId);
        btnHomeScreen = (Button) findViewById(R.id.btnRouteCalcToHomeScreenId);
        btnRouteCar = (Button) findViewById(R.id.btnRouteCalcToRouteCarId);

        //setup database helper and result list
        qrDB = new DatabaseHelper(this);
        resultList = new ArrayList<>();

        //fill the inputPermutations using the database of the scanned packages
        Cursor data = qrDB.getListContents();
        if(data.getCount() == 0){
            Toast.makeText(RouteCalculator.this, "The list is empty", Toast.LENGTH_SHORT).show();
        }
        else{
            while(data.moveToNext()){
                resultList.add(data.getString(1));
                inputPermutations = InputAlgorithm(resultList);
            }
        }

        //just for testing, when finished use inputAlgorithm
        testInputPermutations = "cdf";

        //set up and use permutations class: this gives all different deliver order options
        permutations = new Permutations();
        allPermutationsString = permutations.printDistinctPermutn(inputPermutations, "");  //change input here //TODO

        //the options where in the form of a string, and are here converted to an ArrayList
        inputPruning = new ArrayList(Arrays.asList(allPermutationsString.split(" ")));

        //prune the permuted options by checking if they are the same backwards: This halves the permuted options
        pruning = new Pruning();
        inputAlgorithm = pruning.PruningPermutationsList(inputPruning);

        //setup the A* algorithm tester and estimate distance calculator
        testAStar = new Test();
        estimateDistance = new Estimate();

        //setup the A* tester setup
        try {
            testAStar.setUp();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //Setup of the coordinates, connections
        Set<Location> locations = new HashSet<Location>();
        Map<String, Set<String>> connections = new HashMap<>();

        //Coordinates
        locations.add(new Location("s", "s", 1.63, 0));
        locations.add(new Location("a", "a", 2.265, 2.97));
        locations.add(new Location("b", "b", 1.00, 6.95));
        locations.add(new Location("c", "c", 2.265, 9.42));
        locations.add(new Location("d", "d", 2.265, 15.48));
        locations.add(new Location("e", "e", 2.265, 19.19));
        locations.add(new Location("f", "f", 1.00, 19.39));
        locations.add(new Location("g", "g", 2.265, 22.43));

        //Connections
        connections.put("s", Stream.of("a", "b").collect(Collectors.toSet()));
        connections.put("a", Stream.of("s", "c").collect(Collectors.toSet()));
        connections.put("b", Stream.of("s", "c", "f").collect(Collectors.toSet()));
        connections.put("c", Stream.of("a", "b", "d").collect(Collectors.toSet()));
        connections.put("d", Stream.of("c", "f", "e").collect(Collectors.toSet()));
        connections.put("e", Stream.of("d", "g").collect(Collectors.toSet()));
        connections.put("f", Stream.of("d", "g", "b").collect(Collectors.toSet()));
        connections.put("g", Stream.of("e", "f").collect(Collectors.toSet()));

        //map
        map = new Graph<Location>(locations, connections);

        //A* algorithm
        aStarAlgoritm = new AStarAlgoritm<Location>(map, new Estimate(), new Estimate());

        //just a whole lot of prints to show the algorithm in use in the run folder
        //////////////////////////////////////////////////////////////////////////////
        //prints all the permutations                                               //
        System.out.println("All the permutations: "+ inputPruning);                 //
        //prints all the permutations after pruning                                 //
        System.out.println("All the pruned permutations: "+ inputAlgorithm);        //
        //prints the amount of permutations before pruning                          //
        System.out.println("Length before Pruning: "+inputPruning.size());          //
        //prints the amount of permutations after pruning                           //
        System.out.println("Length after Pruning: " +inputAlgorithm.size());        //
        //////////////////////////////////////////////////////////////////////////////

        //here we start using A* to check which route is the fastest
        ArrayList<String> fastestRoute = RoutePlanner(inputAlgorithm);
        tvFinalRoute.setText(fastestRoute.toString());

        //prints the final fastest route
        //////////////////////////////////////////////////////////////////////////////
        System.out.println("The fastest route is = " + fastestRoute);               //
        //////////////////////////////////////////////////////////////////////////////

        //get instance of database and set the reference to Vehicles
        mDatabase = FirebaseDatabase.getInstance().getReference();

        //go to the function that puts the info in the database
        SendDataToDatabase(fastestRoute, fastestRoute.toString());

        //set all the imageViews for the visual
        ImageView imageView_s_to_a = (ImageView) findViewById(R.id.s_to_aIvRCId);
        imageViews.put("imageView_s_to_a", imageView_s_to_a);
        ImageView imageView_a_to_s = (ImageView) findViewById(R.id.a_to_sIvRCId);
        imageViews.put("imageView_a_to_s", imageView_a_to_s);
        ImageView imageView_a_to_c = (ImageView) findViewById(R.id.a_to_cIvRCId);
        imageViews.put("imageView_a_to_c", imageView_a_to_c);
        ImageView imageView_c_to_a = (ImageView) findViewById(R.id.c_to_aIvRCId);
        imageViews.put("imageView_c_to_a", imageView_c_to_a);
        ImageView imageView_s_to_b = (ImageView) findViewById(R.id.s_to_bIvRCId);
        imageViews.put("imageView_s_to_b", imageView_s_to_b);
        ImageView imageView_b_to_s = (ImageView) findViewById(R.id.b_to_sIvRCId);
        imageViews.put("imageView_b_to_s", imageView_b_to_s);
        ImageView imageView_b_to_c = (ImageView) findViewById(R.id.b_to_cIvRCId);
        imageViews.put("imageView_b_to_c", imageView_b_to_c);
        ImageView imageView_c_to_b = (ImageView) findViewById(R.id.c_to_bIvRCId);
        imageViews.put("imageView_c_to_b", imageView_c_to_b);
        ImageView imageView_c_to_d = (ImageView) findViewById(R.id.c_to_dIvRCId);
        imageViews.put("imageView_c_to_d", imageView_c_to_d);
        ImageView imageView_d_to_c = (ImageView) findViewById(R.id.d_to_cIvRCId);
        imageViews.put("imageView_d_to_c", imageView_d_to_c);
        ImageView imageView_d_to_e = (ImageView) findViewById(R.id.d_to_eIvRCId);
        imageViews.put("imageView_d_to_e", imageView_d_to_e);
        ImageView imageView_e_to_d = (ImageView) findViewById(R.id.e_to_dIvRCId);
        imageViews.put("imageView_e_to_d", imageView_e_to_d);
        ImageView imageView_e_to_g = (ImageView) findViewById(R.id.e_to_gIvRCId);
        imageViews.put("imageView_e_to_g", imageView_e_to_g);
        ImageView imageView_g_to_e = (ImageView) findViewById(R.id.g_to_eIvRCId);
        imageViews.put("imageView_g_to_e", imageView_g_to_e);
        ImageView imageView_f_to_g = (ImageView) findViewById(R.id.f_to_gIvRCId);
        imageViews.put("imageView_f_to_g", imageView_f_to_g);
        ImageView imageView_g_to_f = (ImageView) findViewById(R.id.g_to_fIvRCId);
        imageViews.put("imageView_g_to_f", imageView_g_to_f);
        ImageView imageView_f_to_d = (ImageView) findViewById(R.id.f_to_dIvRCId);
        imageViews.put("imageView_f_to_d", imageView_f_to_d);
        ImageView imageView_d_to_f = (ImageView) findViewById(R.id.d_to_fIvRCId);
        imageViews.put("imageView_d_to_f", imageView_d_to_f);
        ImageView imageView_f_to_b = (ImageView) findViewById(R.id.f_to_bIvRCId);
        imageViews.put("imageView_f_to_b", imageView_f_to_b);
        ImageView imageView_b_to_f = (ImageView) findViewById(R.id.b_to_fIvRCId);
        imageViews.put("imageView_b_to_f", imageView_b_to_f);

        //make the visual run
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {

            @Override
            public void run() {
                CreateMap(fastestRoute);
            }
        }, 3000); //delay so that it does not start immediately

        //deletes the earlier scanned internal database
        //happens as last so that the algorithm has the time to use the info
        qrDB.deleteData();
    }

    //A function that converts an ArrayList of stings into a normal string
    public String InputAlgorithm(ArrayList<String> inputList){
        int index = 0;
        StringBuilder answer = new StringBuilder();
        for(int count = 0; count < inputList.size(); count++){

            if (inputList.get(index).contains(",")){
                String whole = inputList.get(index).trim().toLowerCase();
                String[] parts = whole.split(",");
                String name = parts[0].trim();
                String location = parts[1].trim().toLowerCase();

                answer.append(location);
            }
            else {
                answer.append(inputList.get(index).trim().toLowerCase());
            }

            index++;
        }
        return answer.toString().trim();
    }


    public ArrayList<String> RoutePlanner(ArrayList<String> inputAlgorithm){

        //the answer of the fastest route
        ArrayList<String> fastestRoute = new ArrayList<>();

        //a variable holder to keep track which route was the fastest yet
        double shortestDistance = 9999999999999999.99;

        //a loop trough all the permutation options
        int indexOne = 0;
        for (int countOne = 0; countOne < inputAlgorithm.size(); countOne++){

            //get one option out of the input
            String oneOption = inputAlgorithm.get(indexOne);
            //System.out.println("" +oneOption);

            //convert the permutation option to an List of that option
            ArrayList<String> oneOptionList = new ArrayList<>();
            for (int countTwo = 0; countTwo < oneOption.length(); countTwo++){
                oneOptionList.add(Character.toString(oneOption.charAt(countTwo)));
            }

            //of every list calculate the fastest route between 2 options and build a full list of the fastest route
            ArrayList<String> fastestRouteOfThisOption = new ArrayList<>();
            fastestRouteOfThisOption.add("s");      //add the s as starting station
            int indexThree = 0;
            for (int countThree = 0; countThree < oneOptionList.size() - 1; countThree++){

                //setting the from and to station
                String fromStation = oneOptionList.get(indexThree);
                String toStation = oneOptionList.get(indexThree + 1);

                //using the A* tester to calculate the shortest route
                ArrayList<String> fastestRouteOfThisOptionPart = testAStar.findRoute(fromStation, toStation);

                //remove the first part of the list, else their will be duplicates in the list
                fastestRouteOfThisOptionPart.remove(0);
                //add the part list to the full list
                fastestRouteOfThisOption.addAll(fastestRouteOfThisOptionPart);

                //increment the index
                indexThree++;
            }

            //use the DistanceCalculator() to calculate the distance of this path
            double lengthOfThisRoute = DistanceCalculator(fastestRouteOfThisOption);

            //if statement to check if .lengthOfThisRoute. < .shortestDistance.
            if (lengthOfThisRoute < shortestDistance){
                //[yes] override .shortestDistance. with .lengthOfThisRoute. [and] override .fastestRoute.
                shortestDistance = lengthOfThisRoute;
                fastestRoute = fastestRouteOfThisOption;
            }

            //prints the fastest route of the current option
            System.out.println("fastest route of option: "+oneOption+" = "+fastestRouteOfThisOption);
            //prints the length of this fastest route
            System.out.println("Length of this route = " + lengthOfThisRoute + " meter");

            //increment the index
            indexOne++;
        }

        //return the fastest route that goes along every entered station
        return fastestRoute;
    }

    //function to calculate the distance of an ArrayList and return a double
    public double DistanceCalculator(ArrayList<String> fastestRouteOfThisOption){

        //the final distance set as a double variable
        double distance = 0.0;

        //loop trough all the strings in the list
        for (int count = 0; count < fastestRouteOfThisOption.size() - 1; count++) {

            //get from and to station
            String stationA = fastestRouteOfThisOption.get(count);
            String stationB = fastestRouteOfThisOption.get(count+1);

            //build a list of locations out of the already existing list using the aStarAlgoritm class its function find route
            //We will just pass on two stations that are connected to each other so the shortest route is always that route
            List<Location> locationsList = aStarAlgoritm.findRoute(map.getNode(stationA), map.getNode(stationB));

            //build a location variable that holds all the information about the location
            Location location = locationsList.remove(0);

            //while the list is not empty add the estimate distance by using the Estimate class
            while (!locationsList.isEmpty()) {
                distance += new Estimate().computeCost(location, locationsList.get(0));
                location = locationsList.remove(0);
            }
        }

        //return the final distance
        return distance;
    }


    private void SendDataToDatabase(ArrayList<String> fastestRoute, String fastestRouteString){

        mDatabase = FirebaseDatabase.getInstance().getReference();

        //This is for which vehicle the path is [Can be initialised with NFC but is an extension]
        String vehicleNumber = "4";

        //fill in the new vehicle using the Vehicle() class
        Vehicle vehicle = new Vehicle(fastestRoute, fastestRouteString);

        //set the value of the fastest route to the database at the correct vehicle
        mDatabase.child("Vehicles").child("Vehicle "+ vehicleNumber).setValue(vehicle);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnRouteCalcToHomeScreenId) {
            BackToHomeScreen();
        } else if (v.getId() == R.id.btnRouteCalcToRouteCarId) {
            ToOnRoute();
        }
    }

    private void BackToHomeScreen(){
        //should set that this car is now driving
        startActivity(new Intent(RouteCalculator.this, HomeScreenSender.class));
    }

    private void ToOnRoute(){
        startActivity(new Intent(RouteCalculator.this, PlanningSender.class));
    }

    //create the visual
    private void CreateMap(ArrayList<String> route) {
        final ArrayList<String> finalRoute = route;

        Handler handler1 = new Handler();
        for (int count = 0; count < finalRoute.size()-1 ; count++) {
            int finalCount = count;
            handler1.postDelayed(new Runnable() {
                @Override
                public void run() {
                    String stationFrom = finalRoute.get(finalCount);
                    String stationTo = finalRoute.get(finalCount + 1);

                    String fromToString = "imageView_" + stationFrom + "_to_" + stationTo;

                    imageViews.get(fromToString).setVisibility(View.VISIBLE);

                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {

                        @Override
                        public void run() {
                                imageViews.get(fromToString).setVisibility(View.INVISIBLE);

                            handler.postDelayed(this, 1000);
                        }
                    }, 1000);

                }

            }, 1000 * count);
        }
    }



}
