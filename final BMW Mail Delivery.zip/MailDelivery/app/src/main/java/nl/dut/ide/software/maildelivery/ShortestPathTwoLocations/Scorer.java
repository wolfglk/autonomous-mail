/*
Scorer generates a score to the next node, and an estimate to the destination.
Given a start and an end node a score is generated for traveling between them."
 */

package nl.dut.ide.software.maildelivery.ShortestPathTwoLocations;

public interface Scorer<T extends GraphNode> {
    double computeCost(T from, T to);
}
