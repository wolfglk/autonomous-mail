/*
Location models the nodes, which are represented by locations.
Nodes are represented by locations.
Names are used in output, x and y are used for scoring.
 */


package nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Map;

import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.GraphNode;

import java.util.StringJoiner;

public class Location implements GraphNode {
    private final String id;
    private final String name;
    private final double x;
    private final double y;

    public Location(String id, String name, double x, double y) {
        this.id = id;
        this.name = name;
        this.x = x;
        this.y = y;
    }

    @Override
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Location.class.getSimpleName() + "[", "]").add("id='" + id + "'")
                .add("name='" + name + "'").add("x=" + x).add("y=" + y).toString();
    }
}