package nl.dut.ide.software.maildelivery.QRcode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

import nl.dut.ide.software.maildelivery.R;
import nl.dut.ide.software.maildelivery.login.Login;
import nl.dut.ide.software.maildelivery.sender.RouteCalculator;

public class QRListContent extends AppCompatActivity implements View.OnClickListener{

    DatabaseHelper qrDB;
    ListView qrResults;
    Button resetButton;
    Button sendList;
    ArrayList<String> resultList;

    ImageView ivQRListToHomeScreen;
    Button btnQRListLogOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrlist_content);

        getSupportActionBar().setTitle("BMW Mail Delivery: List of packages");

        qrResults = (ListView)findViewById(R.id.listResults);
        resetButton = (Button) findViewById(R.id.resetButton);
        sendList = (Button) findViewById(R.id.sendCar);

        ivQRListToHomeScreen = (ImageView) findViewById(R.id.ivQRListToHomeScreenId);
        btnQRListLogOut = (Button) findViewById(R.id.btnQRListLogOutId);

        qrDB = new DatabaseHelper(this);

        ResetOnClick();
        SendListOnClick();

        resultList = new ArrayList<>();

        Cursor data = qrDB.getListContents();

        if(data.getCount() == 0){
            //Toast.makeText(QRListContent.this, "The list is empty", Toast.LENGTH_SHORT).show();
        }
        else{
            while(data.moveToNext()){
                resultList.add(data.getString(1));
                ListAdapter listAdapter = new ArrayAdapter<>(this, R.layout.row,resultList);
                qrResults.setAdapter(listAdapter);
            }
        }
    }

    public void ResetOnClick(){
        //At click delete data from list
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor data = qrDB.getListContents();
                if(data.getCount() == 0) {
                    //when list is empty tell the user
                    //Toast toast = Toast.makeText(QRListContent.this, "The list is empty", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.BOTTOM, 0, 500);
                    //toast.show();
                }
                else{
                    Toast toast = Toast.makeText(QRListContent.this, "Successfully cleared list", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.BOTTOM, 0, 500);
                    toast.show();
                    qrDB.deleteData();
                }
            }
        });
    }

    public void SendListOnClick(){
        sendList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor data = qrDB.getListContents();
                //send data to algorithm.
                if(data.getCount() == 0) {
                    Toast.makeText(QRListContent.this, "The list is empty", Toast.LENGTH_SHORT).show();
                }
                else{
                    //Toast.makeText(QRListContent.this, "Successfully send to deliver", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(QRListContent.this, RouteCalculator.class));
                }
            }
        });
    }

    @Override
    public void onClick(View v){
        if (v.getId() == R.id.btnQRListLogOutId){
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(QRListContent.this, Login.class));
        }
        else if (v.getId() == R.id.ivQRListToHomeScreenId){
            startActivity(new Intent(QRListContent.this, QRScanner.class));
        }
    }

}
