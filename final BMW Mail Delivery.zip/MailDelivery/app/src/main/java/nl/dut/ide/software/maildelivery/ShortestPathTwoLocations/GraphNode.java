// GraphNode represents the individual nodes

package nl.dut.ide.software.maildelivery.ShortestPathTwoLocations;

public interface GraphNode {
    String getId();
}