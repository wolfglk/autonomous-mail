package nl.dut.ide.software.maildelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import nl.dut.ide.software.maildelivery.sender.RouteCalculator;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set title of the action bar
        getSupportActionBar().setTitle("BMW Mail Delivery");

        //delay of the start up screen and where to go next
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent fromMainToNext = new Intent(MainActivity.this, RouteCalculator.class); //this one can be changed to test one page
                startActivity(fromMainToNext);
                finish();
            }
        }, 3000); //gives the time it takes to start up
    }
}
