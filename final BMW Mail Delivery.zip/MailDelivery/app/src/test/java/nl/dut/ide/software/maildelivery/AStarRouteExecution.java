/*
AStarRouteExecution stores coordinates of locations and the connections between locations
@Test findRoute line 59, set desired locations to calculate shortest path
 */
package nl.dut.ide.software.maildelivery;

import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.AStarAlgoritm;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Map.Estimate;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Graph;
import nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Map.Location;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class AStarRouteExecution {

    private Graph<Location> map;

    private nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.AStarAlgoritm<Location> AStarAlgoritm;

    private nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Map.Location location;

    private nl.dut.ide.software.maildelivery.ShortestPathTwoLocations.Map.Estimate estimate;


    @Before
    public void setUp() throws Exception {
        Set<Location> locations = new HashSet<>();
        Map<String, Set<String>> connections = new HashMap<>();

        //Coordinates
        locations.add(new Location("s", "s", 1.63, 0));
        locations.add(new Location("a", "a", 2.265, 2.97));
        locations.add(new Location("b", "b", 1.00, 6.95));
        locations.add(new Location("c", "c", 2.265, 9.42));
        locations.add(new Location("d", "d", 2.265, 15.48));
        locations.add(new Location("e", "e", 2.265, 19.19));
        locations.add(new Location("f", "f", 1.00, 19.39));
        locations.add(new Location("g", "g", 2.265, 22.43));

        map = new Graph<>(locations, connections);

        connections.put("s", Stream.of("a", "b").collect(Collectors.toSet()));
        connections.put("a", Stream.of("s", "c").collect(Collectors.toSet()));
        connections.put("b", Stream.of("s", "c").collect(Collectors.toSet()));
        connections.put("c", Stream.of("a", "b", "d").collect(Collectors.toSet()));
        connections.put("d", Stream.of("c", "f", "e").collect(Collectors.toSet()));
        connections.put("e", Stream.of("d", "g").collect(Collectors.toSet()));
        connections.put("f", Stream.of("d", "g").collect(Collectors.toSet()));
        connections.put("g", Stream.of("e", "f").collect(Collectors.toSet()));

        AStarAlgoritm = new AStarAlgoritm<>(map, new Estimate(), new Estimate());
    }

    @Test
    public void findRoute() {
        List<Location> route = AStarAlgoritm.findRoute(map.getNode("s"), map.getNode("c"));

        System.out.println(route.stream().map(Location::getName).collect(Collectors.toList()));
    }


}